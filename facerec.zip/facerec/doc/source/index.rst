facerec
=======

facerec implements a face recognition framework for Python.


.. toctree::
   :maxdepth: 2

   overview
   install/index
   concepts/index
   examples/index

